import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { Loader2, Server, Users, Activity, TrendingUp } from "lucide-react";
import { useEffect, useState } from "react";

export default function Dashboard() {
  const { user } = useAuth();
  const [stats, setStats] = useState<any>(null);
  const [serverStats, setServerStats] = useState<any>(null);
  const [playerStats, setPlayerStats] = useState<any>(null);

  const dashboardStats = trpc.dashboard.getStats.useQuery();
  const serverStatsQuery = trpc.dashboard.getServerStats.useQuery();
  const playerStatsQuery = trpc.dashboard.getPlayerStats.useQuery();

  useEffect(() => {
    if (dashboardStats.data) setStats(dashboardStats.data);
    if (serverStatsQuery.data) setServerStats(serverStatsQuery.data);
    if (playerStatsQuery.data) setPlayerStats(playerStatsQuery.data);
  }, [dashboardStats.data, serverStatsQuery.data, playerStatsQuery.data]);

  if (dashboardStats.isLoading || serverStatsQuery.isLoading || playerStatsQuery.isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="space-y-2">
        <h1 className="neon-title">Game Server Dashboard</h1>
        <div className="neon-accent-line"></div>
        <p className="text-muted-foreground">Welcome back, {user?.name}</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Servers */}
        <Card className="neon-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Server className="w-4 h-4 text-primary" />
              Total Servers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{stats?.totalServers || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">Configured servers</p>
          </CardContent>
        </Card>

        {/* Online Servers */}
        <Card className="neon-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-green-500" />
              Online Servers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-500">{serverStats?.online || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">Currently running</p>
          </CardContent>
        </Card>

        {/* Total Users */}
        <Card className="neon-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Users className="w-4 h-4 text-secondary" />
              Total Users
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-secondary">{stats?.totalUsers || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">Registered accounts</p>
          </CardContent>
        </Card>

        {/* Player Utilization */}
        <Card className="neon-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Activity className="w-4 h-4 text-accent" />
              Utilization
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-accent">{playerStats?.utilizationPercentage || 0}%</div>
            <p className="text-xs text-muted-foreground mt-1">Player capacity</p>
          </CardContent>
        </Card>
      </div>

      {/* Server Status Overview */}
      <Card className="neon-border">
        <CardHeader>
          <CardTitle className="text-lg">Server Status Overview</CardTitle>
          <CardDescription>Current status distribution</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-card rounded-lg neon-border">
              <div className="text-3xl font-bold text-green-500">{serverStats?.online || 0}</div>
              <p className="text-sm text-muted-foreground mt-2">Online</p>
            </div>
            <div className="text-center p-4 bg-card rounded-lg neon-border">
              <div className="text-3xl font-bold text-gray-500">{serverStats?.offline || 0}</div>
              <p className="text-sm text-muted-foreground mt-2">Offline</p>
            </div>
            <div className="text-center p-4 bg-card rounded-lg neon-border">
              <div className="text-3xl font-bold text-yellow-500">{serverStats?.maintenance || 0}</div>
              <p className="text-sm text-muted-foreground mt-2">Maintenance</p>
            </div>
            <div className="text-center p-4 bg-card rounded-lg neon-border">
              <div className="text-3xl font-bold text-red-500">{serverStats?.error || 0}</div>
              <p className="text-sm text-muted-foreground mt-2">Error</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Player Statistics */}
      <Card className="neon-border">
        <CardHeader>
          <CardTitle className="text-lg">Player Statistics</CardTitle>
          <CardDescription>Current player activity</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Total Players Online</span>
              <span className="text-2xl font-bold text-primary">{playerStats?.totalPlayers || 0}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Total Capacity</span>
              <span className="text-2xl font-bold text-secondary">{playerStats?.totalCapacity || 0}</span>
            </div>
            <div className="w-full bg-card rounded-lg h-2 neon-border overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-primary to-secondary transition-all"
                style={{ width: `${playerStats?.utilizationPercentage || 0}%` }}
              ></div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card className="neon-border">
        <CardHeader>
          <CardTitle className="text-lg">Recent Activity</CardTitle>
          <CardDescription>Latest server events</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {stats?.recentActivity && stats.recentActivity.length > 0 ? (
              stats.recentActivity.map((log: any) => (
                <div key={log.id} className="flex items-center justify-between p-3 bg-card rounded-lg neon-border">
                  <div>
                    <p className="font-medium text-sm">{log.description}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {new Date(log.createdAt).toLocaleString()}
                    </p>
                  </div>
                  <span className="px-3 py-1 bg-primary/20 text-primary rounded-full text-xs font-medium">
                    {log.action}
                  </span>
                </div>
              ))
            ) : (
              <p className="text-muted-foreground text-center py-4">No recent activity</p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
