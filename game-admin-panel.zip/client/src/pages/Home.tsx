import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Server, Shield, BarChart3, Zap } from "lucide-react";
import { useLocation } from "wouter";
import { startLogin } from "@/const";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (isAuthenticated && user) {
    return (
      <div className="min-h-screen bg-background">
        {/* Navigation */}
        <nav className="border-b border-border/50 backdrop-blur-sm sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
            <div className="neon-title text-2xl">Game Admin Panel</div>
            <div className="flex items-center gap-4">
              <span className="text-muted-foreground">Welcome, {user.name}</span>
              <Button onClick={() => setLocation("/dashboard")} className="btn-neon">
                Go to Dashboard
              </Button>
            </div>
          </div>
        </nav>

        {/* Hero Section */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="space-y-6">
            <h1 className="neon-title text-5xl md:text-6xl leading-tight">
              Game Server Administration
            </h1>
            <div className="neon-accent-line"></div>
            <p className="text-xl text-muted-foreground max-w-2xl">
              Manage your game servers with a powerful, intuitive control panel. Monitor performance, manage users, and control server operations in real-time.
            </p>
            <div className="flex gap-4 pt-4">
              <Button onClick={() => setLocation("/dashboard")} className="btn-neon-pink gap-2 text-lg px-8 py-6">
                <Zap className="w-5 h-5" />
                Access Dashboard
              </Button>
              <Button onClick={() => setLocation("/api-docs")} variant="outline" className="neon-border gap-2 text-lg px-8 py-6">
                <Shield className="w-5 h-5" />
                API Documentation
              </Button>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <h2 className="neon-title text-3xl mb-12">Key Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: <Server className="w-8 h-8" />,
                title: "Server Management",
                description: "Create, configure, and manage multiple game servers",
              },
              {
                icon: <BarChart3 className="w-8 h-8" />,
                title: "Real-time Monitoring",
                description: "Monitor server status and player activity in real-time",
              },
              {
                icon: <Shield className="w-8 h-8" />,
                title: "User Management",
                description: "Control access with role-based permissions",
              },
              {
                icon: <Zap className="w-8 h-8" />,
                title: "Quick Controls",
                description: "Start, stop, and restart servers with one click",
              },
            ].map((feature, idx) => (
              <Card key={idx} className="neon-border hover:neon-glow transition-all">
                <CardHeader>
                  <div className="text-primary mb-2">{feature.icon}</div>
                  <CardTitle className="text-lg">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Quick Links Section */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <h2 className="neon-title text-3xl mb-12">Quick Links</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                title: "Dashboard",
                description: "View overall statistics and recent activity",
                path: "/dashboard",
                color: "text-primary",
              },
              {
                title: "Servers",
                description: "Manage and control your game servers",
                path: "/servers",
                color: "text-secondary",
              },
              {
                title: "Activity Logs",
                description: "Review server events and user actions",
                path: "/logs",
                color: "text-accent",
              },
              {
                title: "User Management",
                description: "Manage user accounts and permissions",
                path: "/users",
                color: "text-primary",
              },
              {
                title: "API Documentation",
                description: "Complete tRPC API reference",
                path: "/api-docs",
                color: "text-secondary",
              },
              {
                title: "System Settings",
                description: "Configure system-wide settings",
                path: "/dashboard",
                color: "text-accent",
              },
            ].map((link, idx) => (
              <Card
                key={idx}
                className="neon-border cursor-pointer hover:neon-glow-pink transition-all"
                onClick={() => setLocation(link.path)}
              >
                <CardHeader>
                  <CardTitle className={`text-lg ${link.color}`}>{link.title}</CardTitle>
                  <CardDescription>{link.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button variant="outline" className="w-full">
                    Go to {link.title}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Footer */}
        <footer className="border-t border-border/50 mt-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="text-center text-muted-foreground">
              <p>Game Server Administration Panel v1.0.0</p>
              <p className="text-sm mt-2">Powered by Node.js, Express, and tRPC</p>
            </div>
          </div>
        </footer>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="flex flex-col items-center gap-8 p-8 max-w-md w-full">
        <div className="flex flex-col items-center gap-6">
          <h1 className="neon-title text-4xl text-center">Game Admin Panel</h1>
          <div className="neon-accent-line"></div>
          <p className="text-lg text-muted-foreground text-center">
            Sign in to access the game server administration panel
          </p>
        </div>
        <Button
          onClick={() => startLogin()}
          size="lg"
          className="btn-neon-pink w-full gap-2 text-lg"
        >
          <Shield className="w-5 h-5" />
          Sign in with Manus
        </Button>
      </div>
    </div>
  );
}
