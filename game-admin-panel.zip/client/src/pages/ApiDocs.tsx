import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Code2, Database, Server, Users, Activity, Settings } from "lucide-react";

export default function ApiDocs() {
  const procedures = [
    {
      category: "Dashboard",
      icon: <Database className="w-5 h-5" />,
      endpoints: [
        {
          name: "dashboard.getStats",
          type: "query",
          description: "Get overall dashboard statistics",
          input: "{ }",
          output: "{ totalServers, onlineServers, totalUsers, recentActivity }",
          example: "trpc.dashboard.getStats.useQuery()",
        },
        {
          name: "dashboard.getServerStats",
          type: "query",
          description: "Get server status distribution",
          input: "{ }",
          output: "{ online, offline, maintenance, error, total }",
          example: "trpc.dashboard.getServerStats.useQuery()",
        },
        {
          name: "dashboard.getPlayerStats",
          type: "query",
          description: "Get player statistics",
          input: "{ }",
          output: "{ totalPlayers, totalCapacity, utilizationPercentage, serverCount }",
          example: "trpc.dashboard.getPlayerStats.useQuery()",
        },
      ],
    },
    {
      category: "Servers",
      icon: <Server className="w-5 h-5" />,
      endpoints: [
        {
          name: "servers.list",
          type: "query",
          description: "List all game servers",
          input: "{ limit?: number, offset?: number }",
          output: "GameServer[]",
          example: "trpc.servers.list.useQuery({ limit: 50 })",
        },
        {
          name: "servers.getById",
          type: "query",
          description: "Get a specific server by ID",
          input: "{ id: number }",
          output: "GameServer",
          example: "trpc.servers.getById.useQuery({ id: 1 })",
        },
        {
          name: "servers.create",
          type: "mutation",
          description: "Create a new game server (admin only)",
          input: "{ name, gameType, ipAddress, port, maxPlayers, region, description }",
          output: "{ success: true, serverId: number }",
          example: "trpc.servers.create.useMutation()",
        },
        {
          name: "servers.update",
          type: "mutation",
          description: "Update server configuration (admin only)",
          input: "{ id, name?, gameType?, maxPlayers?, region?, description? }",
          output: "{ success: true }",
          example: "trpc.servers.update.useMutation()",
        },
        {
          name: "servers.delete",
          type: "mutation",
          description: "Delete a game server (admin only)",
          input: "{ id: number }",
          output: "{ success: true }",
          example: "trpc.servers.delete.useMutation()",
        },
        {
          name: "servers.start",
          type: "mutation",
          description: "Start a game server (admin only)",
          input: "{ id: number }",
          output: "{ success: true }",
          example: "trpc.servers.start.useMutation()",
        },
        {
          name: "servers.stop",
          type: "mutation",
          description: "Stop a game server (admin only)",
          input: "{ id: number }",
          output: "{ success: true }",
          example: "trpc.servers.stop.useMutation()",
        },
        {
          name: "servers.restart",
          type: "mutation",
          description: "Restart a game server (admin only)",
          input: "{ id: number }",
          output: "{ success: true }",
          example: "trpc.servers.restart.useMutation()",
        },
      ],
    },
    {
      category: "Users",
      icon: <Users className="w-5 h-5" />,
      endpoints: [
        {
          name: "users.me",
          type: "query",
          description: "Get current user profile",
          input: "{ }",
          output: "User",
          example: "trpc.users.me.useQuery()",
        },
        {
          name: "users.list",
          type: "query",
          description: "List all users (admin only)",
          input: "{ limit?: number, offset?: number }",
          output: "User[]",
          example: "trpc.users.list.useQuery({ limit: 50 })",
        },
        {
          name: "users.updateRole",
          type: "mutation",
          description: "Update user role (admin only)",
          input: "{ userId: number, role: 'admin' | 'user' }",
          output: "{ success: true }",
          example: "trpc.users.updateRole.useMutation()",
        },
        {
          name: "users.disable",
          type: "mutation",
          description: "Disable user account (admin only)",
          input: "{ userId: number }",
          output: "{ success: true }",
          example: "trpc.users.disable.useMutation()",
        },
        {
          name: "users.enable",
          type: "mutation",
          description: "Enable user account (admin only)",
          input: "{ userId: number }",
          output: "{ success: true }",
          example: "trpc.users.enable.useMutation()",
        },
      ],
    },
    {
      category: "Activity Logs",
      icon: <Activity className="w-5 h-5" />,
      endpoints: [
        {
          name: "logs.list",
          type: "query",
          description: "List activity logs",
          input: "{ serverId?: number, limit?: number }",
          output: "ActivityLog[]",
          example: "trpc.logs.list.useQuery({ limit: 50 })",
        },
        {
          name: "logs.exportJSON",
          type: "query",
          description: "Export logs as JSON",
          input: "{ limit?: number }",
          output: "{ data: ActivityLog[], exportedAt: Date, format: 'json' }",
          example: "trpc.logs.exportJSON.useQuery({ limit: 100 })",
        },
        {
          name: "logs.exportCSV",
          type: "query",
          description: "Export logs as CSV",
          input: "{ limit?: number }",
          output: "{ data: string, filename: string, format: 'csv' }",
          example: "trpc.logs.exportCSV.useQuery({ limit: 100 })",
        },
      ],
    },
    {
      category: "Configuration",
      icon: <Settings className="w-5 h-5" />,
      endpoints: [
        {
          name: "config.getServerConfig",
          type: "query",
          description: "Get server configuration",
          input: "{ serverId: number }",
          output: "ServerConfig[]",
          example: "trpc.config.getServerConfig.useQuery({ serverId: 1 })",
        },
        {
          name: "config.setServerConfig",
          type: "mutation",
          description: "Set server configuration (admin only)",
          input: "{ serverId, key, value, description? }",
          output: "{ success: true }",
          example: "trpc.config.setServerConfig.useMutation()",
        },
        {
          name: "config.getSystemConfig",
          type: "query",
          description: "Get system configuration (admin only)",
          input: "{ }",
          output: "SystemConfig",
          example: "trpc.config.getSystemConfig.useQuery()",
        },
      ],
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="space-y-2">
        <h1 className="neon-title">API Documentation</h1>
        <div className="neon-accent-line"></div>
        <p className="text-muted-foreground">Complete tRPC API reference for Game Server Admin Panel</p>
      </div>

      {/* Introduction */}
      <Card className="neon-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Code2 className="w-5 h-5" />
            Getting Started
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-semibold mb-2">Base URL</h3>
            <code className="bg-card p-2 rounded block text-sm">
              /api/trpc
            </code>
          </div>
          <div>
            <h3 className="font-semibold mb-2">Authentication</h3>
            <p className="text-sm text-muted-foreground">
              All requests are authenticated via Manus OAuth. Session cookies are automatically handled by the client.
            </p>
          </div>
          <div>
            <h3 className="font-semibold mb-2">Usage Example</h3>
            <code className="bg-card p-3 rounded block text-sm overflow-x-auto">
{`// Query
const { data } = trpc.dashboard.getStats.useQuery();

// Mutation
const mutation = trpc.servers.create.useMutation();
await mutation.mutateAsync({
  name: "My Server",
  gameType: "CS:GO",
  ipAddress: "192.168.1.1",
  port: 27015,
  maxPlayers: 64,
  region: "US-East"
});`}
            </code>
          </div>
        </CardContent>
      </Card>

      {/* API Endpoints */}
      <Tabs defaultValue="Dashboard" className="space-y-4">
        <TabsList className="grid grid-cols-2 md:grid-cols-5 w-full">
          {procedures.map((proc) => (
            <TabsTrigger key={proc.category} value={proc.category} className="text-xs md:text-sm">
              {proc.category}
            </TabsTrigger>
          ))}
        </TabsList>

        {procedures.map((proc) => (
          <TabsContent key={proc.category} value={proc.category} className="space-y-4">
            {proc.endpoints.map((endpoint, idx) => (
              <Card key={idx} className="neon-border">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-base">{endpoint.name}</CardTitle>
                      <CardDescription>{endpoint.description}</CardDescription>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      endpoint.type === "query"
                        ? "bg-blue-500/20 text-blue-500"
                        : "bg-green-500/20 text-green-500"
                    }`}>
                      {endpoint.type}
                    </span>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-semibold text-sm mb-2">Input</h4>
                      <code className="bg-card p-2 rounded block text-xs overflow-x-auto">
                        {endpoint.input}
                      </code>
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm mb-2">Output</h4>
                      <code className="bg-card p-2 rounded block text-xs overflow-x-auto">
                        {endpoint.output}
                      </code>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm mb-2">Example</h4>
                    <code className="bg-card p-3 rounded block text-xs overflow-x-auto">
                      {endpoint.example}
                    </code>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>
        ))}
      </Tabs>

      {/* Response Format */}
      <Card className="neon-border">
        <CardHeader>
          <CardTitle>Response Format</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h4 className="font-semibold text-sm mb-2">Success Response</h4>
            <code className="bg-card p-3 rounded block text-xs overflow-x-auto">
{`{
  "result": {
    "data": { /* endpoint-specific data */ }
  }
}`}
            </code>
          </div>
          <div>
            <h4 className="font-semibold text-sm mb-2">Error Response</h4>
            <code className="bg-card p-3 rounded block text-xs overflow-x-auto">
{`{
  "error": {
    "code": "UNAUTHORIZED" | "FORBIDDEN" | "NOT_FOUND" | "BAD_REQUEST",
    "message": "Error description"
  }
}`}
            </code>
          </div>
        </CardContent>
      </Card>

      {/* Error Codes */}
      <Card className="neon-border">
        <CardHeader>
          <CardTitle>Error Codes</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="font-semibold">UNAUTHORIZED</span>
              <span className="text-muted-foreground">User is not authenticated</span>
            </div>
            <div className="flex justify-between">
              <span className="font-semibold">FORBIDDEN</span>
              <span className="text-muted-foreground">User lacks required permissions</span>
            </div>
            <div className="flex justify-between">
              <span className="font-semibold">NOT_FOUND</span>
              <span className="text-muted-foreground">Requested resource not found</span>
            </div>
            <div className="flex justify-between">
              <span className="font-semibold">BAD_REQUEST</span>
              <span className="text-muted-foreground">Invalid input parameters</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
