import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/_core/hooks/useAuth";
import { Loader2, Download, Filter } from "lucide-react";
import { toast } from "sonner";

export default function ActivityLogs() {
  const { user } = useAuth();
  const [filterAction, setFilterAction] = useState<string>("");
  const [limit, setLimit] = useState(50);

  const logsQuery = trpc.logs.list.useQuery({ limit });
  const exportJSONQuery = trpc.logs.exportJSON.useQuery({ limit }, { enabled: false });
  const exportCSVQuery = trpc.logs.exportCSV.useQuery({ limit }, { enabled: false });

  const handleExportJSON = async () => {
    try {
      const result = await exportJSONQuery.refetch();
      if (result.data) {
        const dataStr = JSON.stringify(result.data.data, null, 2);
        const dataBlob = new Blob([dataStr], { type: "application/json" });
        const url = URL.createObjectURL(dataBlob);
        const link = document.createElement("a");
        link.href = url;
        link.download = `activity-logs-${new Date().toISOString().split("T")[0]}.json`;
        link.click();
        toast.success("Logs exported as JSON");
      }
    } catch (error) {
      toast.error("Failed to export logs");
    }
  };

  const handleExportCSV = async () => {
    try {
      const result = await exportCSVQuery.refetch();
      if (result.data) {
        const dataBlob = new Blob([result.data.data], { type: "text/csv" });
        const url = URL.createObjectURL(dataBlob);
        const link = document.createElement("a");
        link.href = url;
        link.download = result.data.filename;
        link.click();
        toast.success("Logs exported as CSV");
      }
    } catch (error) {
      toast.error("Failed to export logs");
    }
  };

  const filteredLogs = logsQuery.data?.filter((log: any) => !filterAction || log.action === filterAction) || [];

  const actions = ["start", "stop", "restart", "config_change", "player_update", "status_change", "created", "deleted", "edited"];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="space-y-2">
        <h1 className="neon-title">Activity Logs</h1>
        <div className="neon-accent-line"></div>
        <p className="text-muted-foreground">Server events and user actions</p>
      </div>

      {/* Filters and Export */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1 flex gap-2">
          <Select value={filterAction} onValueChange={setFilterAction}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue placeholder="Filter by action..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All Actions</SelectItem>
              {actions.map((action) => (
                <SelectItem key={action} value={action}>
                  {action.replace("_", " ")}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={String(limit)} onValueChange={(v) => setLimit(parseInt(v))}>
            <SelectTrigger className="w-24">
              <SelectValue placeholder="Limit" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="25">25</SelectItem>
              <SelectItem value="50">50</SelectItem>
              <SelectItem value="100">100</SelectItem>
              <SelectItem value="250">250</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {user?.role === "admin" && (
          <div className="flex gap-2">
            <Button
              onClick={handleExportJSON}
              variant="outline"
              className="gap-2"
              disabled={exportJSONQuery.isLoading}
            >
              <Download className="w-4 h-4" />
              JSON
            </Button>
            <Button
              onClick={handleExportCSV}
              variant="outline"
              className="gap-2"
              disabled={exportCSVQuery.isLoading}
            >
              <Download className="w-4 h-4" />
              CSV
            </Button>
          </div>
        )}
      </div>

      {/* Logs Table */}
      {logsQuery.isLoading ? (
        <div className="flex items-center justify-center h-32">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : (
        <Card className="neon-border">
          <CardContent className="pt-6">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 font-semibold text-muted-foreground">Timestamp</th>
                    <th className="text-left py-3 px-4 font-semibold text-muted-foreground">Action</th>
                    <th className="text-left py-3 px-4 font-semibold text-muted-foreground">Description</th>
                    <th className="text-left py-3 px-4 font-semibold text-muted-foreground">User</th>
                    <th className="text-left py-3 px-4 font-semibold text-muted-foreground">Server</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredLogs.map((log: any) => (
                    <tr key={log.id} className="border-b border-border hover:bg-card/50 transition-colors">
                      <td className="py-3 px-4 text-xs">
                        {new Date(log.createdAt).toLocaleString()}
                      </td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-1 bg-primary/20 text-primary rounded text-xs font-medium">
                          {log.action}
                        </span>
                      </td>
                      <td className="py-3 px-4">{log.description}</td>
                      <td className="py-3 px-4 text-xs text-muted-foreground">User #{log.userId}</td>
                      <td className="py-3 px-4 text-xs text-muted-foreground">Server #{log.serverId}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {filteredLogs.length === 0 && (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No activity logs found</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Stats */}
      <Card className="neon-border">
        <CardHeader>
          <CardTitle className="text-lg">Activity Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {actions.map((action) => {
              const count = logsQuery.data?.filter((log: any) => log.action === action).length || 0;
              return (
                <div key={action} className="text-center p-3 bg-card rounded-lg neon-border">
                  <div className="text-2xl font-bold text-primary">{count}</div>
                  <p className="text-xs text-muted-foreground mt-1">{action.replace("_", " ")}</p>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
