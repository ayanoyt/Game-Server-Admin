import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useAuth } from "@/_core/hooks/useAuth";
import { Loader2, Plus, Play, Square, RotateCw, Trash2, Edit2, Search } from "lucide-react";
import { toast } from "sonner";

export default function Servers() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    gameType: "",
    ipAddress: "",
    port: 27015,
    maxPlayers: 64,
    region: "US-East",
    description: "",
  });

  const serversQuery = trpc.servers.list.useQuery({ limit: 100 });
  const createServerMutation = trpc.servers.create.useMutation();
  const startServerMutation = trpc.servers.start.useMutation();
  const stopServerMutation = trpc.servers.stop.useMutation();
  const restartServerMutation = trpc.servers.restart.useMutation();
  const deleteServerMutation = trpc.servers.delete.useMutation();

  const handleCreateServer = async () => {
    try {
      await createServerMutation.mutateAsync(formData);
      toast.success("Server created successfully");
      setIsCreateOpen(false);
      setFormData({
        name: "",
        gameType: "",
        ipAddress: "",
        port: 27015,
        maxPlayers: 64,
        region: "US-East",
        description: "",
      });
      serversQuery.refetch();
    } catch (error) {
      toast.error("Failed to create server");
    }
  };

  const handleStartServer = async (id: number) => {
    try {
      await startServerMutation.mutateAsync({ id });
      toast.success("Server started");
      serversQuery.refetch();
    } catch (error) {
      toast.error("Failed to start server");
    }
  };

  const handleStopServer = async (id: number) => {
    try {
      await stopServerMutation.mutateAsync({ id });
      toast.success("Server stopped");
      serversQuery.refetch();
    } catch (error) {
      toast.error("Failed to stop server");
    }
  };

  const handleRestartServer = async (id: number) => {
    try {
      await restartServerMutation.mutateAsync({ id });
      toast.success("Server restarting");
      serversQuery.refetch();
    } catch (error) {
      toast.error("Failed to restart server");
    }
  };

  const handleDeleteServer = async (id: number) => {
    if (confirm("Are you sure you want to delete this server?")) {
      try {
        await deleteServerMutation.mutateAsync({ id });
        toast.success("Server deleted");
        serversQuery.refetch();
      } catch (error) {
        toast.error("Failed to delete server");
      }
    }
  };

  const filteredServers = serversQuery.data?.filter((server: any) =>
    server.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    server.gameType.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h1 className="neon-title">Game Servers</h1>
          {user?.role === "admin" && (
            <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
              <DialogTrigger asChild>
                <Button className="btn-neon-pink gap-2">
                  <Plus className="w-4 h-4" />
                  Add Server
                </Button>
              </DialogTrigger>
              <DialogContent className="neon-border">
                <DialogHeader>
                  <DialogTitle>Create New Game Server</DialogTitle>
                  <DialogDescription>Add a new game server to your panel</DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <Input
                    placeholder="Server Name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  />
                  <Input
                    placeholder="Game Type (e.g., CS:GO, Minecraft)"
                    value={formData.gameType}
                    onChange={(e) => setFormData({ ...formData, gameType: e.target.value })}
                  />
                  <Input
                    placeholder="IP Address"
                    value={formData.ipAddress}
                    onChange={(e) => setFormData({ ...formData, ipAddress: e.target.value })}
                  />
                  <Input
                    type="number"
                    placeholder="Port"
                    value={formData.port}
                    onChange={(e) => setFormData({ ...formData, port: parseInt(e.target.value) })}
                  />
                  <Input
                    type="number"
                    placeholder="Max Players"
                    value={formData.maxPlayers}
                    onChange={(e) => setFormData({ ...formData, maxPlayers: parseInt(e.target.value) })}
                  />
                  <Input
                    placeholder="Region"
                    value={formData.region}
                    onChange={(e) => setFormData({ ...formData, region: e.target.value })}
                  />
                  <Input
                    placeholder="Description (optional)"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  />
                  <Button onClick={handleCreateServer} className="btn-neon w-full" disabled={createServerMutation.isPending}>
                    {createServerMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Create Server"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </div>
        <div className="neon-accent-line"></div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search servers..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Servers List */}
      {serversQuery.isLoading ? (
        <div className="flex items-center justify-center h-32">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredServers.map((server: any) => (
            <Card key={server.id} className="neon-border">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg">{server.name}</CardTitle>
                    <CardDescription>{server.gameType}</CardDescription>
                  </div>
                  <span className={`status-${server.status}`}>{server.status}</span>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">IP:Port</span>
                    <span>{server.ipAddress}:{server.port}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Players</span>
                    <span>{server.currentPlayers}/{server.maxPlayers}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Region</span>
                    <span>{server.region}</span>
                  </div>
                </div>

                {user?.role === "admin" && (
                  <div className="flex gap-2 pt-4 border-t border-border">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleStartServer(server.id)}
                      disabled={server.status === "online"}
                      className="flex-1 gap-1"
                    >
                      <Play className="w-3 h-3" />
                      Start
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleStopServer(server.id)}
                      disabled={server.status === "offline"}
                      className="flex-1 gap-1"
                    >
                      <Square className="w-3 h-3" />
                      Stop
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleRestartServer(server.id)}
                      className="flex-1 gap-1"
                    >
                      <RotateCw className="w-3 h-3" />
                      Restart
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleDeleteServer(server.id)}
                      className="flex-1 gap-1"
                    >
                      <Trash2 className="w-3 h-3" />
                      Delete
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {filteredServers.length === 0 && !serversQuery.isLoading && (
        <Card className="neon-border">
          <CardContent className="text-center py-8">
            <p className="text-muted-foreground">No servers found</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
