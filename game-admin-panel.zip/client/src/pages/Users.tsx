import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/_core/hooks/useAuth";
import { Loader2, Search, Shield, User } from "lucide-react";
import { toast } from "sonner";

export default function Users() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");

  const usersQuery = trpc.users.list.useQuery({ limit: 100 });
  const updateRoleMutation = trpc.users.updateRole.useMutation();
  const disableUserMutation = trpc.users.disable.useMutation();
  const enableUserMutation = trpc.users.enable.useMutation();

  const handleUpdateRole = async (userId: number, role: "admin" | "user") => {
    try {
      await updateRoleMutation.mutateAsync({ userId, role });
      toast.success("User role updated");
      usersQuery.refetch();
    } catch (error) {
      toast.error("Failed to update user role");
    }
  };

  const handleDisableUser = async (userId: number) => {
    if (confirm("Are you sure you want to disable this user account?")) {
      try {
        await disableUserMutation.mutateAsync({ userId });
        toast.success("User account disabled");
        usersQuery.refetch();
      } catch (error) {
        toast.error("Failed to disable user");
      }
    }
  };

  const handleEnableUser = async (userId: number) => {
    try {
      await enableUserMutation.mutateAsync({ userId });
      toast.success("User account enabled");
      usersQuery.refetch();
    } catch (error) {
      toast.error("Failed to enable user");
    }
  };

  if (user?.role !== "admin") {
    return (
      <div className="flex items-center justify-center h-screen">
        <Card className="neon-border">
          <CardContent className="pt-6">
            <p className="text-muted-foreground">You do not have permission to access this page</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const filteredUsers = usersQuery.data?.filter((u: any) =>
    u.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.email?.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="space-y-2">
        <h1 className="neon-title">User Management</h1>
        <div className="neon-accent-line"></div>
        <p className="text-muted-foreground">Manage user accounts and permissions</p>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search users by name or email..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Users Table */}
      {usersQuery.isLoading ? (
        <div className="flex items-center justify-center h-32">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : (
        <Card className="neon-border">
          <CardContent className="pt-6">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 font-semibold text-muted-foreground">Name</th>
                    <th className="text-left py-3 px-4 font-semibold text-muted-foreground">Email</th>
                    <th className="text-left py-3 px-4 font-semibold text-muted-foreground">Role</th>
                    <th className="text-left py-3 px-4 font-semibold text-muted-foreground">Status</th>
                    <th className="text-left py-3 px-4 font-semibold text-muted-foreground">Joined</th>
                    <th className="text-left py-3 px-4 font-semibold text-muted-foreground">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredUsers.map((u: any) => (
                    <tr key={u.id} className="border-b border-border hover:bg-card/50 transition-colors">
                      <td className="py-3 px-4 flex items-center gap-2">
                        {u.role === "admin" ? (
                          <Shield className="w-4 h-4 text-secondary" />
                        ) : (
                          <User className="w-4 h-4 text-muted-foreground" />
                        )}
                        {u.name}
                      </td>
                      <td className="py-3 px-4 text-xs text-muted-foreground">{u.email}</td>
                      <td className="py-3 px-4">
                        <Select
                          value={u.role}
                          onValueChange={(role) => handleUpdateRole(u.id, role as "admin" | "user")}
                        >
                          <SelectTrigger className="w-24 h-8">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="user">User</SelectItem>
                            <SelectItem value="admin">Admin</SelectItem>
                          </SelectContent>
                        </Select>
                      </td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-1 rounded text-xs font-medium ${
                          u.isDisabled
                            ? "bg-red-500/20 text-red-500"
                            : "bg-green-500/20 text-green-500"
                        }`}>
                          {u.isDisabled ? "Disabled" : "Active"}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-xs text-muted-foreground">
                        {new Date(u.createdAt).toLocaleDateString()}
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex gap-2">
                          {u.isDisabled ? (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleEnableUser(u.id)}
                              className="text-xs"
                            >
                              Enable
                            </Button>
                          ) : (
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleDisableUser(u.id)}
                              className="text-xs"
                            >
                              Disable
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {filteredUsers.length === 0 && (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No users found</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* User Statistics */}
      <Card className="neon-border">
        <CardHeader>
          <CardTitle className="text-lg">User Statistics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-3 bg-card rounded-lg neon-border">
              <div className="text-2xl font-bold text-primary">{usersQuery.data?.length || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">Total Users</p>
            </div>
            <div className="text-center p-3 bg-card rounded-lg neon-border">
              <div className="text-2xl font-bold text-secondary">
                {usersQuery.data?.filter((u: any) => u.role === "admin").length || 0}
              </div>
              <p className="text-xs text-muted-foreground mt-1">Admins</p>
            </div>
            <div className="text-center p-3 bg-card rounded-lg neon-border">
              <div className="text-2xl font-bold text-green-500">
                {usersQuery.data?.filter((u: any) => !u.isDisabled).length || 0}
              </div>
              <p className="text-xs text-muted-foreground mt-1">Active</p>
            </div>
            <div className="text-center p-3 bg-card rounded-lg neon-border">
              <div className="text-2xl font-bold text-red-500">
                {usersQuery.data?.filter((u: any) => u.isDisabled).length || 0}
              </div>
              <p className="text-xs text-muted-foreground mt-1">Disabled</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
