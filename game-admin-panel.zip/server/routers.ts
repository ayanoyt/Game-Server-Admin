import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { serversRouter } from "./routers/servers";
import { logsRouter } from "./routers/logs";
import { usersRouter } from "./routers/users";
import { dashboardRouter } from "./routers/dashboard";
import { configRouter } from "./routers/config";
import { backupsRouter } from "./routers/backups";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  servers: serversRouter,
  logs: logsRouter,
  users: usersRouter,
  dashboard: dashboardRouter,
  config: configRouter,
  backups: backupsRouter,
});

export type AppRouter = typeof appRouter;
